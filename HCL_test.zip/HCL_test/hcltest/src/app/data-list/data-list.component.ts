import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-data-list',
  templateUrl: './data-list.component.html',
  styleUrls: ['./data-list.component.css']
})
export class DataListComponent implements OnInit {

  dataList = [];

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
  }

  getData() {
    this.dataService.getData().subscribe((data) => {
      this.dataList = data;
    });
  }

}
